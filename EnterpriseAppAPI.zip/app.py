
from flask import Flask, request, jsonify, send_from_directory
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'output'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/build-app', methods=['POST'])
def build_app():
    ipa = request.files.get('ipa')
    if not ipa:
        return jsonify({"error": "No IPA uploaded"}), 400

    ipa.save(os.path.join(UPLOAD_FOLDER, ipa.filename))

    manifest_url = f"https://yourdomain.com/{UPLOAD_FOLDER}/manifest.plist"
    return jsonify({
        "message": "App uploaded successfully",
        "ipa_url": f"https://yourdomain.com/{UPLOAD_FOLDER}/{ipa.filename}",
        "manifest_url": f"itms-services://?action=download-manifest&url={manifest_url}"
    })

@app.route('/output/<path:filename>')
def serve_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
